# LE MAESTRO — Viral Intelligence System

Directeur artistique IA pour TikTok · Reels · Shorts

## Stack
- **Next.js 14** (App Router)
- **Google Gemini 1.5 Flash** (API gratuite)
- **Vercel** (hébergement gratuit)

---

## 🚀 DÉPLOIEMENT EN 5 ÉTAPES

### Étape 1 — Obtenir la clé API Gemini (GRATUIT)
1. Va sur https://aistudio.google.com/app/apikey
2. Clique **"Create API Key"**
3. Copie ta clé (commence par `AIza...`)

### Étape 2 — Mettre le projet sur GitHub
1. Crée un compte sur https://github.com
2. Crée un nouveau dépôt (New Repository) → nom : `le-maestro`
3. Sur ton ordinateur, ouvre le terminal dans ce dossier et tape :
```bash
git init
git add .
git commit -m "Le Maestro MVP v1.0"
git remote add origin https://github.com/TON_USERNAME/le-maestro.git
git push -u origin main
```

### Étape 3 — Déployer sur Vercel (GRATUIT)
1. Va sur https://vercel.com et connecte-toi avec GitHub
2. Clique **"Add New Project"**
3. Sélectionne ton dépôt `le-maestro`
4. Clique **"Deploy"** (Vercel détecte Next.js automatiquement)

### Étape 4 — Ajouter la clé API sur Vercel
1. Dans ton projet Vercel → **Settings → Environment Variables**
2. Ajoute :
   - **Name** : `GEMINI_API_KEY`
   - **Value** : ta clé `AIza...`
3. Clique **Save**
4. Retourne dans **Deployments** → clique les 3 points → **Redeploy**

### Étape 5 — Ton app est en ligne !
URL automatique : `le-maestro.vercel.app`
Tu peux la partager à tout le monde.

---

## 📁 Structure du Projet

```
le-maestro/
├── app/
│   ├── layout.js          # Layout global + fonts
│   ├── globals.css         # CSS global + animations
│   ├── page.js             # Page principale (UI complète)
│   └── api/
│       └── analyze/
│           └── route.js    # Route API → Gemini (SÉCURISÉE)
├── lib/
│   └── extractFrames.js    # Extraction frames vidéo (client)
├── .env.local              # ⚠️ NE JAMAIS COMMIT CE FICHIER
├── .env.example            # Exemple de config
├── .gitignore
├── next.config.js
└── package.json
```

---

## 🔒 Sécurité
- La clé API Gemini n'est **jamais** exposée au client
- Rate limit basique : 10 requêtes/heure par IP
- `.env.local` est dans `.gitignore` (ne sera jamais sur GitHub)

## 🆓 Limites du tier gratuit Gemini
- 15 requêtes/minute
- 1 million de tokens/jour
- Modèle : `gemini-1.5-flash`

## ⬆️ Pour passer en production sérieuse
- Ajouter une base de données (Supabase) pour les limites par utilisateur
- Ajouter Stripe pour la monétisation
- Passer à `gemini-1.5-pro` pour plus de qualité
