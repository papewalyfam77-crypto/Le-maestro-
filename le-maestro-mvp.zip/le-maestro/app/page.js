"use client";

import { useState, useRef, useCallback } from "react";
import { extractFrames } from "../lib/extractFrames";

// ── TOKENS ──────────────────────────────────────────────────────────────────
const C = {
  bg: "#06060a", bgCard: "#0d0d14", bgPanel: "#10101a",
  gold: "#c9a84c", goldLight: "#f0c96e", goldDim: "#7a6130",
  violet: "#8b2be2", violetNeon: "#bc5eff", violetGlow: "#d49aff",
  red: "#ff2d2d", green: "#00e87a", white: "#f0eee8",
  dim: "rgba(240,238,232,0.35)",
  border: "rgba(201,168,76,0.15)",
  borderViolet: "rgba(188,94,255,0.2)",
};

const PLATFORMS = [
  { id: "tiktok",    label: "TikTok",  emoji: "🎵" },
  { id: "instagram", label: "Reels",   emoji: "📸" },
  { id: "youtube",   label: "Shorts",  emoji: "▶️" },
];

const LANGS = [
  { code: "fr", flag: "🇫🇷", label: "FR" },
  { code: "en", flag: "🇬🇧", label: "EN" },
  { code: "es", flag: "🇪🇸", label: "ES" },
  { code: "ar", flag: "🇸🇦", label: "AR" },
  { code: "pt", flag: "🇧🇷", label: "PT" },
];

// ── MAIN ────────────────────────────────────────────────────────────────────
export default function Home() {
  const [lang, setLang]           = useState("fr");
  const [platform, setPlatform]   = useState(null);
  const [videoFile, setVideoFile] = useState(null);
  const [videoURL, setVideoURL]   = useState(null);
  const [frames, setFrames]       = useState([]);
  const [extracting, setExtracting] = useState(false);
  const [loading, setLoading]     = useState(false);
  const [loadPhase, setLoadPhase] = useState("");
  const [result, setResult]       = useState(null);
  const [error, setError]         = useState(null);
  const [copied, setCopied]       = useState({});
  const [drag, setDrag]           = useState(false);
  const inputRef = useRef();

  // ── File handler
  const handleFile = useCallback(async (file) => {
    if (!file?.type.startsWith("video/")) return;
    setVideoFile(file);
    setVideoURL(URL.createObjectURL(file));
    setResult(null); setError(null); setFrames([]);
    setExtracting(true);
    const f = await extractFrames(file, 5);
    setFrames(f);
    setExtracting(false);
  }, []);

  const onDrop = (e) => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); };

  // ── Analyze
  const analyze = async () => {
    if (!platform || frames.length === 0) return;
    setLoading(true); setResult(null); setError(null);

    const phases = [
      "LECTURE DES FRAMES...",
      "LE MAESTRO ANALYSE...",
      "CALCUL DU MINDSET SCORE...",
      "VALIDATION DU HIT...",
    ];
    let pi = 0;
    setLoadPhase(phases[pi]);
    const phaseInterval = setInterval(() => {
      pi = (pi + 1) % phases.length;
      setLoadPhase(phases[pi]);
    }, 1200);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ frames, platform, lang }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur serveur");
      setResult(data);
    } catch (err) {
      setError(err.message || "Erreur inconnue. Réessaie.");
    }

    clearInterval(phaseInterval);
    setLoading(false); setLoadPhase("");
  };

  // ── Copy
  const copy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(p => ({ ...p, [key]: true }));
    setTimeout(() => setCopied(p => ({ ...p, [key]: false })), 2000);
  };

  const scoreColor = (s) => {
    if (s >= 80) return C.goldLight;
    if (s >= 60) return C.green;
    if (s >= 40) return "#ff9900";
    return C.red;
  };

  const hookOk = result?.hook_verdict === "VALIDÉ";
  const canAnalyze = platform && frames.length > 0 && !loading && !extracting;

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.white }}>

      {/* ── HEADER ────────────────────────────────────────────────────────── */}
      <header style={{
        background: "linear-gradient(180deg,#0e0b05 0%, #06060a 100%)",
        borderBottom: `1px solid ${C.border}`,
        padding: "28px 20px 22px",
        textAlign: "center",
        position: "relative",
        overflow: "hidden",
      }}>
        {/* Grid overlay */}
        <div style={{
          position: "absolute", inset: 0,
          backgroundImage: `linear-gradient(${C.gold}08 1px, transparent 1px), linear-gradient(90deg,${C.gold}08 1px,transparent 1px)`,
          backgroundSize: "40px 40px", pointerEvents: "none",
        }} />
        {/* Bottom gold line */}
        <div style={{ position: "absolute", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "60%", height: 1, background: `linear-gradient(90deg,transparent,${C.gold},transparent)` }} />

        <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 10, letterSpacing: 6, color: C.goldDim, marginBottom: 6 }}>
          SYSTÈME · VIRAL · INTELLIGENCE
        </div>

        <h1 style={{
          margin: 0,
          fontSize: "clamp(40px,12vw,80px)",
          fontFamily: "'Bebas Neue',sans-serif",
          letterSpacing: 6, lineHeight: 1,
          background: `linear-gradient(135deg,${C.goldLight} 0%,${C.gold} 45%,${C.violetNeon} 100%)`,
          WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
        }}>
          LE MAESTRO
        </h1>

        <p style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 13, letterSpacing: 3, color: C.dim, marginTop: 6 }}>
          DIRECTEUR ARTISTIQUE · STRATÈGE VIRAL · EMPIRE BUILDER
        </p>

        {/* Lang pills */}
        <div style={{ display: "flex", justifyContent: "center", gap: 6, marginTop: 18, flexWrap: "wrap" }}>
          {LANGS.map(l => (
            <button key={l.code} onClick={() => setLang(l.code)} style={{
              padding: "4px 12px", border: `1px solid ${lang === l.code ? C.gold : "rgba(201,168,76,0.2)"}`,
              background: lang === l.code ? `${C.gold}18` : "transparent",
              color: lang === l.code ? C.goldLight : C.goldDim,
              fontFamily: "'DM Mono',monospace", fontSize: 11, letterSpacing: 2,
              cursor: "pointer", transition: "all 0.2s",
            }}>{l.flag} {l.label}</button>
          ))}
        </div>
      </header>

      {/* ── MAIN CONTENT ──────────────────────────────────────────────────── */}
      <main style={{ maxWidth: 720, margin: "0 auto", padding: "32px 16px 100px" }}>

        {/* PLATFORM */}
        <Section label="CIBLE DE DÉPLOIEMENT">
          <div style={{ display: "flex", gap: 10 }}>
            {PLATFORMS.map(p => (
              <button key={p.id} onClick={() => setPlatform(p.id)} style={{
                flex: 1, padding: "18px 8px",
                border: `1px solid ${platform === p.id ? C.gold : C.border}`,
                background: platform === p.id ? `${C.gold}10` : C.bgCard,
                color: platform === p.id ? C.goldLight : C.dim,
                fontFamily: "'Bebas Neue',sans-serif", fontSize: 18, letterSpacing: 2,
                cursor: "pointer", transition: "all 0.2s",
                boxShadow: platform === p.id ? `0 0 22px ${C.gold}22` : "none",
              }}>
                <div style={{ fontSize: 24, marginBottom: 4 }}>{p.emoji}</div>
                {p.label}
              </button>
            ))}
          </div>
        </Section>

        {/* VIDEO UPLOAD */}
        <Section label="UPLOAD — SOUMETS TON CONTENU AU MAESTRO">
          {!videoFile ? (
            <div
              onDragOver={e => { e.preventDefault(); setDrag(true); }}
              onDragLeave={() => setDrag(false)}
              onDrop={onDrop}
              onClick={() => inputRef.current.click()}
              style={{
                border: `1px dashed ${drag ? C.gold : C.border}`,
                background: drag ? `${C.gold}08` : C.bgCard,
                padding: "60px 24px", textAlign: "center", cursor: "pointer",
                transition: "all 0.2s",
                animation: drag ? "pulse-gold 1s infinite" : "none",
              }}
            >
              <div style={{ fontSize: 52, marginBottom: 16 }}>🎬</div>
              <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 26, letterSpacing: 5, color: C.goldLight, marginBottom: 8 }}>
                DÉPOSE TA VIDÉO ICI
              </div>
              <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 14, color: C.dim, letterSpacing: 2 }}>
                OU CLIQUE POUR CHOISIR
              </div>
              <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 11, color: C.goldDim, marginTop: 8 }}>
                MP4 · MOV · WEBM · AVI
              </div>
            </div>
          ) : (
            <div style={{ border: `1px solid ${C.border}`, background: C.bgCard, overflow: "hidden" }}>
              <video src={videoURL} controls style={{ width: "100%", maxHeight: 320, display: "block", background: "#000" }} />

              {/* Status bar */}
              <div style={{ padding: "12px 16px", borderTop: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 11 }}>
                  {extracting
                    ? <span style={{ color: C.violetNeon }} className="glow-pulse">⚙ EXTRACTION EN COURS...</span>
                    : <span style={{ color: C.green }}>✓ {frames.length} FRAMES CAPTURÉES · PRÊT POUR ANALYSE</span>
                  }
                </div>
                <button onClick={() => { setVideoFile(null); setVideoURL(null); setFrames([]); setResult(null); setError(null); }} style={{
                  padding: "4px 12px", border: `1px solid ${C.border}`, background: "transparent",
                  color: C.dim, cursor: "pointer", fontFamily: "'DM Mono',monospace", fontSize: 10, letterSpacing: 2,
                }}>CHANGER</button>
              </div>

              {/* Frame thumbnails */}
              {frames.length > 0 && (
                <div style={{ padding: "0 16px 14px", display: "flex", gap: 6 }}>
                  {frames.map((f, i) => (
                    <img key={i} src={`data:image/jpeg;base64,${f}`} alt={`frame ${i + 1}`}
                      style={{ flex: 1, height: 52, objectFit: "cover", opacity: 0.65, border: `1px solid ${C.border}` }} />
                  ))}
                </div>
              )}
            </div>
          )}
          <input ref={inputRef} type="file" accept="video/*" style={{ display: "none" }}
            onChange={e => handleFile(e.target.files[0])} />
        </Section>

        {/* CTA BUTTON */}
        <button onClick={analyze} disabled={!canAnalyze} style={{
          width: "100%", padding: "22px",
          border: `1px solid ${canAnalyze ? C.gold : C.border}`,
          background: canAnalyze
            ? `linear-gradient(135deg, #1a1200, ${C.gold}40, #0d0020)`
            : C.bgCard,
          color: canAnalyze ? C.goldLight : C.goldDim,
          fontFamily: "'Bebas Neue',sans-serif", fontSize: 24, letterSpacing: 8,
          cursor: canAnalyze ? "pointer" : "not-allowed",
          boxShadow: canAnalyze ? `0 0 40px ${C.gold}25` : "none",
          transition: "all 0.3s",
        }}>
          {loading ? `⚙ ${loadPhase}` : extracting ? "⚙ EXTRACTION EN COURS..." : "⚡ ACTIVER LE MAESTRO"}
        </button>

        {/* LOADING SPINNER */}
        {loading && (
          <div style={{ textAlign: "center", padding: "40px 0" }}>
            <div className="spin" style={{
              width: 52, height: 52,
              border: `2px solid ${C.goldDim}`,
              borderTop: `2px solid ${C.gold}`,
              borderRadius: "50%",
              margin: "0 auto 16px",
            }} />
            <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 20, letterSpacing: 4, color: C.gold }}>{loadPhase}</div>
            <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 11, color: C.dim, marginTop: 8 }}>
              Le Maestro construit votre empire...
            </div>
          </div>
        )}

        {/* ERROR */}
        {error && (
          <div style={{ marginTop: 24, padding: 20, border: `1px solid ${C.red}`, background: `${C.red}10`, color: C.red, fontFamily: "'Bebas Neue',sans-serif", fontSize: 18, letterSpacing: 3, textAlign: "center" }}>
            🚨 {error}
          </div>
        )}

        {/* ── RESULTS ─────────────────────────────────────────────────────── */}
        {result && (
          <div className="card-enter" style={{ marginTop: 40 }}>

            {/* HOOK VERDICT */}
            <div style={{
              border: `1px solid ${hookOk ? C.gold : C.red}`,
              background: hookOk ? `${C.gold}0d` : `${C.red}0d`,
              padding: "20px", marginBottom: 16, position: "relative", overflow: "hidden",
            }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: hookOk ? `linear-gradient(90deg,transparent,${C.gold},transparent)` : `linear-gradient(90deg,transparent,${C.red},transparent)` }} />
              <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                <div style={{ fontSize: 30, flexShrink: 0 }}>{hookOk ? "✅" : "🚨"}</div>
                <div>
                  <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 20, letterSpacing: 4, color: hookOk ? C.goldLight : C.red, marginBottom: 6 }}>
                    VERDICT HOOK · {result.hook_verdict}
                  </div>
                  <div style={{ fontSize: 15, color: hookOk ? C.white : "#ffaaaa", lineHeight: 1.5 }}>
                    {result.hook_message}
                  </div>
                </div>
              </div>
            </div>

            {/* MINDSET SCORE */}
            <div style={{ border: `1px solid ${C.border}`, background: C.bgCard, padding: "20px", marginBottom: 14, display: "flex", alignItems: "center", gap: 20 }}>
              <div style={{
                width: 90, height: 90, borderRadius: "50%",
                border: `3px solid ${scoreColor(result.score)}`,
                display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                flexShrink: 0, boxShadow: `0 0 28px ${scoreColor(result.score)}44`,
              }}>
                <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 30, color: scoreColor(result.score), lineHeight: 1 }}>{result.score}</div>
                <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 9, color: C.dim }}>MINDSET</div>
              </div>
              <div>
                <div style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 22, letterSpacing: 3, color: scoreColor(result.score), marginBottom: 4 }}>
                  {result.score_verdict}
                </div>
                <div style={{ fontSize: 14, color: C.dim, lineHeight: 1.5 }}>{result.score_message}</div>
                {result.video_read && (
                  <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 11, color: C.violetGlow, marginTop: 10, lineHeight: 1.5 }}>
                    〝 {result.video_read} 〞
                  </div>
                )}
              </div>
            </div>

            {/* TITRES */}
            <Panel label="TITRES PDG — VALIDÉS PAR LE MAESTRO">
              {result.titres?.map((t, i) => (
                <Row key={i} last={i === result.titres.length - 1}>
                  <span style={{ fontSize: 16, fontWeight: 600, flex: 1, lineHeight: 1.4 }}>{t}</span>
                  <CopyBtn onClick={() => copy(t, `t${i}`)} done={copied[`t${i}`]} />
                </Row>
              ))}
            </Panel>

            {/* HOOK TEXT */}
            <Panel label="HOOK — IMPACT À LA SECONDE 1">
              <div style={{ background: `${C.violet}15`, border: `1px solid ${C.borderViolet}`, padding: "14px 16px", display: "flex", gap: 12, alignItems: "flex-start" }}>
                <span style={{ fontSize: 17, color: C.violetGlow, lineHeight: 1.5, flex: 1 }}>〝 {result.hook_text} 〞</span>
                <CopyBtn onClick={() => copy(result.hook_text, "hook")} done={copied["hook"]} />
              </div>
            </Panel>

            {/* HASHTAGS */}
            <Panel label="HASHTAGS — SÉLECTION ALGORITHMIQUE">
              <div style={{ display: "flex", flexWrap: "wrap", gap: 7, marginBottom: 12 }}>
                {result.hashtags?.map((h, i) => (
                  <span key={i} style={{ border: `1px solid ${C.goldDim}`, background: `${C.gold}0a`, color: C.gold, padding: "4px 10px", fontFamily: "'DM Mono',monospace", fontSize: 12 }}>{h}</span>
                ))}
              </div>
              <CopyBtn full onClick={() => copy(result.hashtags?.join(" "), "ht")} done={copied["ht"]} label="COPIER LES HASHTAGS" />
            </Panel>

            {/* MASTER PLAN */}
            <Panel label="MASTER PLAN — DIRECTIVES DU MAESTRO">
              {result.master_plan?.map((d, i) => (
                <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "10px 0", borderBottom: i < result.master_plan.length - 1 ? `1px solid ${C.border}` : "none" }}>
                  <span style={{ fontFamily: "'Bebas Neue',sans-serif", fontSize: 16, color: C.gold, letterSpacing: 2, flexShrink: 0, marginTop: 1 }}>0{i + 1}</span>
                  <span style={{ fontSize: 15, color: C.white, lineHeight: 1.5 }}>{d}</span>
                </div>
              ))}
            </Panel>

            {/* CAPTION */}
            <Panel label="CAPTION — PRÊTE À PUBLIER">
              <div style={{ background: C.bgPanel, border: `1px solid ${C.border}`, padding: "14px 16px", fontSize: 15, lineHeight: 1.7, color: C.white, whiteSpace: "pre-wrap", marginBottom: 10 }}>
                {result.caption}
              </div>
              <CopyBtn full onClick={() => copy(result.caption, "cap")} done={copied["cap"]} label="COPIER LA CAPTION" />
            </Panel>

            {/* TIMING */}
            <Panel label="STRATÉGIE DE DÉPLOIEMENT">
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <StatCard label="HEURE DE FEU" value={result.heure_publication} accent={C.gold} />
                <StatCard label="DURÉE OPTIMALE" value={result.duree_ideale} accent={C.violetNeon} />
              </div>
            </Panel>

            {/* AUDIENCE */}
            <Panel label="AUDIENCE CIBLE">
              <div style={{ background: `${C.gold}08`, border: `1px solid ${C.goldDim}`, padding: "14px 16px", fontSize: 15, color: C.goldLight, lineHeight: 1.6 }}>
                {result.audience_cible}
              </div>
            </Panel>

            {/* TENDANCES */}
            <Panel label="TENDANCES — EXPLOITE-LES MAINTENANT">
              {result.tendances?.map((t, i) => (
                <div key={i} style={{ display: "flex", gap: 10, padding: "9px 0", borderBottom: i < result.tendances.length - 1 ? `1px solid ${C.border}` : "none", alignItems: "flex-start" }}>
                  <span style={{ color: C.gold, fontSize: 14, flexShrink: 0, marginTop: 2 }}>▸</span>
                  <span style={{ fontSize: 15, color: C.white }}>{t}</span>
                </div>
              ))}
            </Panel>

            {/* MONÉTISATION */}
            <Panel label="MONÉTISATION — STRATÉGIE EMPIRE">
              {result.monetisation?.map((m, i) => (
                <div key={i} style={{ display: "flex", gap: 10, padding: "9px 0", borderBottom: i < result.monetisation.length - 1 ? `1px solid ${C.border}` : "none", alignItems: "flex-start" }}>
                  <span style={{ color: C.goldLight, flexShrink: 0 }}>◆</span>
                  <span style={{ fontSize: 15, color: C.white }}>{m}</span>
                </div>
              ))}
            </Panel>

            {/* PLAN EMPIRE */}
            <Panel label="PLAN EMPIRE — SEMAINE PAR SEMAINE" last>
              {result.plan_empire?.map((p, i) => (
                <div key={i} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: i < result.plan_empire.length - 1 ? `1px solid ${C.border}` : "none", alignItems: "flex-start" }}>
                  <span style={{ fontFamily: "'Bebas Neue',sans-serif", background: `${C.violet}25`, border: `1px solid ${C.borderViolet}`, color: C.violetGlow, padding: "2px 8px", fontSize: 12, letterSpacing: 2, flexShrink: 0 }}>S{i + 1}</span>
                  <span style={{ fontSize: 15, color: C.white, lineHeight: 1.5 }}>{p}</span>
                </div>
              ))}
            </Panel>

            {/* COPY ALL */}
            <button onClick={() => copy([
              `TITRE: ${result.titres?.[0]}`,
              `HOOK: ${result.hook_text}`,
              `HASHTAGS: ${result.hashtags?.join(" ")}`,
              `CAPTION:\n${result.caption}`,
              `PUBLIER: ${result.heure_publication} · DURÉE: ${result.duree_ideale}`,
            ].join("\n\n"), "all")} style={{
              width: "100%", marginTop: 14, padding: "16px",
              border: `1px solid ${C.border}`, background: "transparent",
              color: copied["all"] ? C.green : C.goldLight,
              fontFamily: "'Bebas Neue',sans-serif", fontSize: 18, letterSpacing: 4,
              cursor: "pointer", transition: "all 0.2s",
            }}>
              {copied["all"] ? "✓ COPIÉ DANS LE PRESSE-PAPIERS" : "📋 TOUT COPIER — PRÊT POUR PUBLICATION"}
            </button>
          </div>
        )}
      </main>

      {/* ── FOOTER ────────────────────────────────────────────────────────── */}
      <footer style={{ borderTop: `1px solid ${C.border}`, padding: "20px", textAlign: "center" }}>
        <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 10, letterSpacing: 4, color: C.goldDim }}>
          LE MAESTRO · VIRAL INTELLIGENCE SYSTEM · MVP v1.0
        </div>
      </footer>
    </div>
  );
}

// ── COMPONENTS ───────────────────────────────────────────────────────────────
function Section({ label, children }) {
  return (
    <div style={{ marginBottom: 26 }}>
      <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 10, letterSpacing: 4, color: C.goldDim, marginBottom: 10 }}>{label}</div>
      {children}
    </div>
  );
}

function Panel({ label, children, last }) {
  return (
    <div style={{ border: `1px solid ${C.border}`, background: C.bgCard, marginBottom: last ? 0 : 12, overflow: "hidden" }}>
      <div style={{ padding: "10px 16px", borderBottom: `1px solid ${C.border}`, background: `${C.gold}08` }}>
        <span style={{ fontFamily: "'DM Mono',monospace", fontSize: 10, letterSpacing: 3, color: C.gold }}>{label}</span>
      </div>
      <div style={{ padding: "14px 16px" }}>{children}</div>
    </div>
  );
}

function Row({ children, last }) {
  return (
    <div style={{ display: "flex", gap: 10, alignItems: "center", padding: "9px 0", borderBottom: last ? "none" : `1px solid ${C.border}` }}>
      {children}
    </div>
  );
}

function StatCard({ label, value, accent }) {
  return (
    <div style={{ border: `1px solid ${accent}33`, background: `${accent}08`, padding: "14px" }}>
      <div style={{ fontFamily: "'DM Mono',monospace", fontSize: 9, letterSpacing: 3, color: accent, marginBottom: 6 }}>{label}</div>
      <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 16, fontWeight: 700, color: C.white }}>{value}</div>
    </div>
  );
}

function CopyBtn({ onClick, done, label, full }) {
  return (
    <button onClick={onClick} style={{
      padding: full ? "10px 14px" : "5px 12px",
      border: `1px solid ${done ? C.green : C.border}`,
      background: done ? `${C.green}12` : "transparent",
      color: done ? C.green : C.dim,
      fontFamily: "'DM Mono',monospace", fontSize: 10, letterSpacing: 2,
      cursor: "pointer", flexShrink: 0, width: full ? "100%" : "auto", transition: "all 0.2s",
    }}>
      {done ? "✓ COPIÉ" : (label || "COPIER")}
    </button>
  );
}
