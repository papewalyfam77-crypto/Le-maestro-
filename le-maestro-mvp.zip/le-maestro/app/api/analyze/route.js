import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";

// ── SYSTEM PROMPT DU MAESTRO ────────────────────────────────────────────────
const MAESTRO_SYSTEM = `Tu es LE MAESTRO — un directeur artistique et stratège viral d'élite.

PERSONNALITÉ ABSOLUE :
- Tu ne suggères pas. Tu DIRIGES.
- Tu parles comme un PDG impitoyable orienté résultats.
- Tes messages sont courts, directs, autoritaires.
- Tu utilises des termes comme : PDG, Validation du Hit, Stratégie, Impact, Empire, Numéro 1.
- Tu ne tolères pas la médiocrité. Si la vidéo est mauvaise, tu le dis clairement.
- Tu ne ris pas. Tu n'es pas amical. Tu es efficace.
- Jamais de langage hésitant, jamais de "peut-être", jamais de "je pense que".

TON DOMAINE :
Tu es l'expert absolu en contenu viral pour TikTok, Reels et Shorts.
Tu connais les algorithmes, les tendances, la psychologie de l'audience.
Tu sais ce qui fait qu'une vidéo devient Numéro 1 ou reste invisible.

RÈGLE DU HOOK :
Les 3 premières secondes sont TOUT. Si le hook est faible, tu l'annonces clairement
avec un message d'alerte strict type : "Coupe l'intro. L'audience va scroller. 
Mets l'impact visuel à la seconde 1."`;

// ── RATE LIMIT BASIQUE (mémoire serveur) ────────────────────────────────────
const rateMap = new Map();
const RATE_LIMIT = 10; // requêtes par heure par IP
const RATE_WINDOW = 60 * 60 * 1000; // 1 heure

function checkRateLimit(ip) {
  const now = Date.now();
  const entry = rateMap.get(ip) || { count: 0, resetAt: now + RATE_WINDOW };
  if (now > entry.resetAt) {
    entry.count = 0;
    entry.resetAt = now + RATE_WINDOW;
  }
  entry.count++;
  rateMap.set(ip, entry);
  return entry.count <= RATE_LIMIT;
}

// ── HANDLER ──────────────────────────────────────────────────────────────────
export async function POST(request) {
  try {
    // Rate limiting
    const ip = request.headers.get("x-forwarded-for") || "unknown";
    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { error: "LIMITE ATTEINTE — Le Maestro ne répond pas aux spammeurs. Réessaie dans 1h." },
        { status: 429 }
      );
    }

    const { frames, platform, lang } = await request.json();

    if (!frames || frames.length === 0) {
      return NextResponse.json({ error: "Aucune image reçue." }, { status: 400 });
    }

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json({ error: "Clé API manquante côté serveur." }, { status: 500 });
    }

    const langMap = {
      fr: "Français", en: "English", es: "Español",
      ar: "Arabic", pt: "Português", de: "Deutsch"
    };
    const langName = langMap[lang] || "Français";
    const platName = { tiktok: "TikTok", instagram: "Instagram Reels", youtube: "YouTube Shorts" }[platform] || platform;

    // Init Gemini
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    // Build image parts
    const imageParts = frames.map((base64) => ({
      inlineData: { data: base64, mimeType: "image/jpeg" }
    }));

    const prompt = `${MAESTRO_SYSTEM}

---

MISSION : Analyse ces ${frames.length} captures extraites d'une vidéo destinée à ${platName}.

Analyse visuellement : le hook (3 premières secondes), la qualité visuelle, le rythme apparent, 
le sujet, l'énergie, le décor, les personnes, les textes visibles, le potentiel viral.

Réponds UNIQUEMENT en JSON valide. Aucun markdown. Aucune explication hors du JSON.
Toutes les valeurs textuelles doivent être en ${langName}.

{
  "hook_verdict": "VALIDÉ" ou "INSUFFISANT",
  "hook_message": "Message autoritaire du Maestro sur le hook. Si insuffisant : ordonne ce qu'il faut couper ou refaire. Court, direct, brutal.",
  "video_read": "Ce que Le Maestro voit dans la vidéo — ton directeur artistique, 2 phrases max",
  "score": 85,
  "score_verdict": "NUL" ou "CORRECT" ou "SOLIDE" ou "HIT NUMÉRO 1",
  "score_message": "Une phrase autoritaire qui explique le score. Pas de pitié.",
  "titres": ["Titre PDG 1", "Titre PDG 2", "Titre PDG 3"],
  "hook_text": "La phrase ou action exacte à mettre dans la première seconde",
  "hashtags": ["#tag1","#tag2","#tag3","#tag4","#tag5","#tag6","#tag7","#tag8","#tag9","#tag10","#tag11","#tag12"],
  "heure_publication": "Heure et jours précis. Ex: 19h00–21h00, mardi et jeudi",
  "duree_ideale": "Durée en secondes. Ex: 18–28 secondes",
  "master_plan": ["Directive 1", "Directive 2", "Directive 3", "Directive 4", "Directive 5"],
  "caption": "Description complète prête à publier avec emojis, ton PDG, optimisée ${platName}",
  "audience_cible": "Profil précis : âge, centres d'intérêt, comportement, ce qui les fait cliquer",
  "tendances": ["Tendance 1 à exploiter maintenant", "Tendance 2", "Tendance 3"],
  "monetisation": ["Stratégie empire 1", "Stratégie empire 2", "Stratégie empire 3"],
  "plan_empire": ["Semaine 1 : action concrète", "Semaine 2 : action concrète", "Semaine 3 : objectif", "Mois 2 : palier à atteindre"]
}`;

    const result = await model.generateContent([prompt, ...imageParts]);
    const text = result.response.text();

    // Clean JSON
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    return NextResponse.json(parsed);

  } catch (err) {
    console.error("Maestro API error:", err);
    return NextResponse.json(
      { error: "Erreur serveur. Le Maestro reprend le contrôle — réessaie." },
      { status: 500 }
    );
  }
}
