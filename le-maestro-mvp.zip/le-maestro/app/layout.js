import './globals.css'

export const metadata = {
  title: 'Le Maestro — Directeur Viral IA',
  description: 'Soumets ta vidéo. Le Maestro analyse, dirige, et valide ton Hit Numéro 1.',
  openGraph: {
    title: 'Le Maestro — Directeur Viral IA',
    description: 'Analyse IA de vidéos courtes. TikTok · Reels · Shorts.',
    type: 'website',
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Barlow+Condensed:wght@300;400;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  )
}
